package com.rewapath.narmada

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
